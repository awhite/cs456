public class EotException extends Exception {
	private static final long serialVersionUID = 1L;

	public EotException() {
		super("EOT");
	}
}
